package main.java.snake_08.upper_01.test01_03;

import demo_06.Interface;

public class Test_01_03_home
{
  public static void main( String[] args )
  {
    Interface save = Calc03.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
