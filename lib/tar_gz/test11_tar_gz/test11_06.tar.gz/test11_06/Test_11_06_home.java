package main.java.snake_08.upper_11.test11_06;

import demo_06.Interface;

public class Test_11_06_home
{
  public static void main( String[] args )
  {
      Interface save = Calc06.create();
        save.execute();

  }
}
