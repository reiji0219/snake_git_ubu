package main.java.snake_08.upper_11.test11_19;

import demo_06.Interface;

public class Test_11_19_home
{
  public static void main( String[] args )
  {
      Interface save = Calc19.create();
        save.execute();
  }
}
