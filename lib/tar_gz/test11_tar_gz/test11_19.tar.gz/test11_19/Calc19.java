package main.java.snake_08.upper_11.test11_19;

import demo_06.Interface;

public class Calc19 extends Item19
{
  private String name;

  public Calc19( String name ){
    super();
    this.name = name;
  }

  public static Interface create(){
    return() -> {
      Calc19 calc = new Calc19( "Poly-morphism" );
      calc.process( () -> {
        System.out.println( "関心事を記述" );

        Item19.save( item -> {
          item.id( "掛け算" )
              .name( "税込み価格" )
              .price( 980 )
              .tax( 1.1 )
              .calc( calc );

          System.out.println( "計算式 :" + item.getId() );

          item.display();

          item.execute();
        });
         System.out.println( "Hello World_1" );
      });
    };
  }

  public void display(){
    indi( name );
  }

  public void process( Interface inter ){
    indi( "start" );

    inter.execute();

    indi( "end" );
  }
}
