package main.java.snake_08.upper_11.test11_04;

import demo_06.Interface;

public class Test_11_04_home
{
  public static void main( String[] args )
  {
      Interface save = Calc04.create();
        save.execute();
  }
}
