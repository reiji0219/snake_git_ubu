package main.java.snake_08.upper_11.test11_11;

import demo_06.Interface;

public class Test_11_11_home
{
  public static void main( String[] args )
  {
    Interface save = Calc11.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
