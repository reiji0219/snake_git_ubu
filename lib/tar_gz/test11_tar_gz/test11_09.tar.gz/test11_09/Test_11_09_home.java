package main.java.snake_08.upper_11.test11_09;

import demo_06.Interface;

public class Test_11_09_home
{
  public static void main( String[] args )
  {
    Interface save = Calc09.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
