package main.java.snake_08.upper_11.test11_18;

import demo_06.Interface;

public class Test_11_18_home
{
  public static void main( String[] args )
  {
    Interface save = Calc18.create();
      save.execute();

    System.out.println( "Hello world_1" );
  }
}
