package main.java.snake_08.upper_11.test11_30;

import demo_06.Interface;

public class Test_11_30_home
{
  public static void main( String[] args )
  {
    Interface save = Calc30.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
