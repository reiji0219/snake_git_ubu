package main.java.snake_08.upper_12.test12_16;

import demo_06.Interface;

public class Test_12_16_home
{
  public static void main( String[] args )
  {
    Interface save = Calc16.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
