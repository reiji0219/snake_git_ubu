package main.java.snake_08.upper_12.test12_04;

import demo_06.Interface;

public class Test_12_04_home
{
  public static void main( String[] args )
  {
    Interface save = Calc04.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
