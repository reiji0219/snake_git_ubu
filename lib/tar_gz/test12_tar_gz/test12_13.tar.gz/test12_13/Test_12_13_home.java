package main.java.snake_08.upper_12.test12_13;

import demo_06.Interface;

public class Test_12_13_home
{
  public static void main( String[] args )
  {
    Interface save = Calc13.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
