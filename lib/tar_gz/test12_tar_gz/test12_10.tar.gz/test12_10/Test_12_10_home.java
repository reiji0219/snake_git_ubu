package main.java.snake_08.upper_12.test12_10;

import demo_06.Interface;

public class Test_12_10_home
{
  public static void main( String[] args )
  {
    Interface save = Calc10.create();
      save.execute();

    System.out.println( "Hello World_1" );
  }
}
