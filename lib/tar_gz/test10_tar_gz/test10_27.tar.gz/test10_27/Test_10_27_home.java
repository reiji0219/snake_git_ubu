package main.java.snake_08.upper_10.test10_27;

import demo_06.Interface;

public class Test_10_27_home
{
  public static void main( String[] args )
  {
    Calc27 calc = new Calc27( "Poly-morphism" );
    calc.pricess( () -> {
      System.out.println( "関心事を記述" );

      Interface save = Calc27.create();
        save.execute();

      System.out.println( "Hello World_1" );
    });
  }
}
