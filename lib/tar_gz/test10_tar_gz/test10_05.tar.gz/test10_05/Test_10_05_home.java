package main.java.snake_08.upper_10.test10_05;

import demo_06.Interface;

public class Test_10_05_home
{
  public static void main( String[] args )
  {
    Calc05 calc = new Calc05( "Poly-morphism" );
    calc.process( () -> {
      System.out.println( "関心事を記述" );

      Interface save = Calc05.create();
        save.execute();

      System.out.println( "Hello World_1" );
    });
  }
}
