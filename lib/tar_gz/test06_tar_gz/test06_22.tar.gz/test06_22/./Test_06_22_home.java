package main.java.snake_07.under_07.test06_22;

import demo_06.Intreface;

public class Test_06_22_home
{
  public static void main( String[] args )
  {
    Calc22 calc = new Calc22( "Poly-morphism" );
    calc.process( () -> {
      System.out.println( "関心事を記述" );

      Intreface save = Calc22.create();
        save.execute();

      System.out.println( "Hello World_1" );
    });
  }
}

