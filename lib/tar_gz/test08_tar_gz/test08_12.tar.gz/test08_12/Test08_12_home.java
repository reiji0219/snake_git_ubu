package main.java.snake_08.upper_08.test08_12;

import demo_06.Interface;

public class Test08_12_home
{
  public static void main( String[] args )
  {
    Calc12 calc = new Calc12( "Poly-morphism" );
    calc.process( () -> {
      System.out.println( "関心事を記述" );

      Interface save = calc.create();
        save.execute();

      System.out.println( "Hello World_1" );
    });
  }
}
