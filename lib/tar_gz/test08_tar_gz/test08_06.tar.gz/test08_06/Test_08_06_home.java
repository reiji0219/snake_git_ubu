package main.java.snake_08.upper_08.test08_11;

import demo_06.Interface;

public class Test_08_06_home
{
  public static void main( String[] args )
  {
    Calc06 calc = new Calc06( "関心事を記述" );
    calc.process( () -> {

     Interface save = Calc06.create();
       save.execute();

      System.out.println( "Hello World_1" );
    });
  }
}
